
function Translation()
{
	var me = this;

    // me.dataSetTag = $("#selectedDataSetId");

	// -----------------------------------------------------------------------------------------------------------------------------------
	// IDs
      
	me.ID_OPTIONSET_TERMS = "wvmkakUiSin";

	me.ID_OPTIONSET_COUNTRIES_GRANTS_BILATERAL_ENTITIES = "JYxH2FHaiX0";
	me.ID_OPTIONSET_COUNTRIES_INT_FOUNDATION_NGO = "Q7z8N3vInmO";
	me.ID_OPTIONSET_COUNTRIES_MULTILATERIAL_ENTITIES = "Lmdrr8Nt9Yb";
	me.ID_OPTIONSET_CURRENCY = "NKBEx7GtFJK";
	me.ID_OPTIONSET_IMPL_STRATEGIES = "SU52yMajLXm";
	me.ID_OPTIONSET_TARGET_POPULATIONS = "e3RJ6M8qB1h";



	// -----------------------------------------------------------------------------------------------------------------------------------
	// URL Queries

	// me.PARAM_DATASET_ID = "@PARAM_DATASET_ID";
	// me.PROJECT_DATASET_URL = "../api/dataSets/" + me.PARAM_DATASET_ID + ".json?fields=dataSetElements[dataElement[id,displayFormName]]";

  	me.OPTION_SET_QUERY_URL = RESTUtil.API_BASED_URL + "optionSets.json?filter=id:in:[" + me.ID_OPTIONSET_COUNTRIES_GRANTS_BILATERAL_ENTITIES 
					+ "," + me.ID_OPTIONSET_COUNTRIES_INT_FOUNDATION_NGO
					+ "," + me.ID_OPTIONSET_COUNTRIES_MULTILATERIAL_ENTITIES 
					+ "," + me.ID_OPTIONSET_IMPL_STRATEGIES 
					+ "," + me.ID_OPTIONSET_TARGET_POPULATIONS 
					+ "," + me.ID_OPTIONSET_CURRENCY 
					+ "," + me.ID_OPTIONSET_TERMS
					+ "]&fields=options[code,displayName]&paging=false";

	// me.DE_GROUP_SET_QUERY_URL = "../api/dataElementGroupSets.json?filter=name:ilike:ABR%20[INF]&fields=id,name,dataElementGroups[id,displayShortName]&paging=false"


	// me.DATAELEMENT_KEY = "DATAELEMENT";
	me.OPTIONSET_KEY = "OPTIONSET";
	// me.DEGROUP_KEY = "DEGROUP";

	me.tableTag = $("body");


	// ----------------------------------------------------------------------------------------------
	// Init method

	me.init = function()
	{
		// me.translateDEGroupSetList();
		// me.translateDataElementList();
		me.translateOptionSetList();
	}

	// ----------------------------------------------------------------------------------------------
	// Supportive methods

	// me.translateDEGroupSetList = function()
	// {
	// 	var url = me.DE_GROUP_SET_QUERY_URL;

	// 	me.loadMetadata( url, function( response ){

	// 		var deGroupSets = response.dataElementGroupSets;
	// 		for( var i in deGroupSets )
	// 		{
	// 			var deGroups = deGroupSets[i].dataElementGroups;
	// 			for( var j in deGroups )
	// 			{
	// 				var deGroup = deGroups[j];
	// 				me.tableTag.find("[keyword='degr_id:" + deGroup.id + "']").html( deGroup.displayShortName );
	// 			}
	// 		}
	// 	} );
		
	// }
	

	// me.translateDataElementList = function()
	// {
	// 	var url = me.PROJECT_DATASET_URL;
	// 	url = url.replace( me.PARAM_DATASET_ID, me.dataSetTag.val() );

	// 	me.loadMetadata( url, function( response ){

	// 		var dataSetElements = response.dataSetElements;
	// 		for( var i in dataSetElements )
	// 		{
	// 			var dataElement = dataSetElements[i].dataElement;
	// 			var value = me.getTransValue ( me.DATAELEMENT_KEY, dataElement );
	// 			me.tableTag.find("[keyword='de_id:" + dataElement.id + "']").html( value );
	// 		}
	// 	} );
		
	// }

	me.translateOptionSetList = function()
	{
		var url = me.OPTION_SET_QUERY_URL;
		me.loadMetadata( url, function( response ){

			var optionSets = response.optionSets;
			for( var i in optionSets )
			{
				var options = optionSets[i].options;
				for( var j in options )
				{
					var option = options[j];
					var value = me.getTransValue ( me.OPTIONSET_KEY, option );
					me.tableTag.find("[keyword='opt_c:" + option.code + "']").html( value );
					me.tableTag.find("[keyword-placeholder='opt_c:" + option.code + "']").attr( "placeholder", value );
				}
			}
		} );
	}

	me.loadMetadata = function( url, exeFunc )
	{ 
          $.ajax({
			type: "GET"
			,url: url
			,contentType: "application/json;charset=utf-8"
			,beforeSend: function( xhr ) 
			{
				//me.hideReportTag();
			}
			,success: function( response ) 
			{		
				exeFunc( response );
			}
			,error: function(response)
			{
				// me.showReportTag();
			}
		  }).always( function( data ) 
		  {
            // me.showReportTag();
          });

    }
	
	me.getTransValue = function( key, data )
	{
		// if( key == me.DATAELEMENT_KEY )
		// {
		// 	if( data)
		// 	return data.displayFormName;
		// }
        // else 
        if( key == me.OPTIONSET_KEY )
		{ 
			return data.displayName;
		}
	}


	// ----------------------------------------------------------------------------------------------
	// init

	me.init();

}
