function ProjectManager()
{
    var me = this;

    me.orgunitTag = $("#orgunit");
    me.periodTag = $("#period");


    me.ORGUNIT_QUERY_URL = RESTUtil.API_BASED_URL + "organisationUnits.json?level=5&fields=name,id&paging=false";

    // =name:ilike:
    me.init = function()
    {
        me.setAutoCompleteForOrgUnit();
    }


    // ------------------------------------------------------------------------------------------------
    // Retrieve data

    me.setAutoCompleteForOrgUnit = function()
    {
        // RESTUtil.retrieveData = function( url, actionSuccess, actionError, loadingStart, loadingEnd ) 

        me.orgunitTag.autocomplete({
            source: function( request, response ) {
              $.ajax( {
                url: me.ORGUNIT_QUERY_URL,
                dataType: "json",
                data: {
                  term: request.filter
                },
                success: function( data ) {
                  response( data );
                }
              } );
            },
            minLength: 2,
            select: function( event, ui ) {
              log( "Selected value: " + ui.item.value + " ID : " + ui.item.id );
            }
          } );
    }


    // ------------------------------------------------------------------------------------------------
    // RUN init method

    me.init();

}